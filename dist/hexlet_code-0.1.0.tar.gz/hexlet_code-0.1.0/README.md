### Hexlet tests and linter status:
[![Actions Status](https://github.com/DimoonNazarov/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/DimoonNazarov/python-project-49/actions)
<a href="https://codeclimate.com/github/DimoonNazarov/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/d35f755e152aade4d1fc/maintainability" /></a>
https://asciinema.org/a/NPAV4pNiImobpBpyGaJFAvVoT
[![asciicast](https://asciinema.org/a/NPAV4pNiImobpBpyGaJFAvVoT.svg)](https://asciinema.org/a/NPAV4pNiImobpBpyGaJFAvVoT)

